#!/bin/sh

# stop aliddns first
enable=`dbus get fastd1ck_enable`
if [ "$enable" == "1" ];then
	sh /koolshare/scripts/fastd1ck_config.sh stop
fi

# delete some files
rm -rf /koolshare/init.d/*FastD1ck.sh

# install
cp -rf /tmp/fastd1ck/scripts/* /koolshare/scripts/
cp -rf /tmp/fastd1ck/webs/* /koolshare/webs/
cp -rf /tmp/fastd1ck/res/* /koolshare/res/
cp -rf /tmp/fastd1ck/install.sh /koolshare/scripts/uninstall_fastd1ck.sh
chmod +x /koolshare/scripts/fastd1ck*
chmod +x /koolshare/init.d/*
[ ! -L "/koolshare/init.d/S9527FastD1ck.sh" ] && ln -sf /koolshare/scripts/fastd1ck_config.sh /koolshare/init.d/S9527FastD1ck.sh

# delete install tar
rm -rf /tmp/fastd1ck* >/dev/null 2>&1

# re-enable aliddns
if [ "$enable" == "1" ];then
	sh /koolshare/scripts/fastd1ck_config.sh &
fi
