#!/bin/sh
export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval `dbus export fastd1ck`

start_fastd1ck(){
	dbus set fastd1ck_currentI=18
	day_of_month_orig=`date +%d`
	orig_day_of_month=`echo $day_of_month_orig|grep -oE "[1-9]{1,2}"`
	dbus set fastd1ck_orig_day_of_month=$orig_day_of_month
	dbus set fastd1ck_day_of_month_orig=$day_of_month_orig
	dbus set fastd1ck_session=""
	dbus set fastd1ck_loginkey=""
	job1exist=`cru l|grep fastd1ck`
	if [ -z "$job1exist" ];then
		cru a fastd1ck "*/10 * * * * /koolshare/scripts/fastd1ck_todo.sh"
	fi
	
	job2exist=`cru l|grep fastd1ck_recover`
	if [ -z "$job2exist" ];then
		cru a fastd1ck_recover "1 0 * * * /koolshare/scripts/fastd1ck_config.sh recover"
	fi
	
	sh /koolshare/scripts/fastd1ck_todo.sh &

	if [ ! -L "/koolshare/init.d/S9527FastD1ck.sh" ]; then 
		ln -sf /koolshare/scripts/fastd1ck_config.sh /koolshare/init.d/S9527FastD1ck.sh
	fi
}

write_shcontent(){
	if [ ! -z "$fastd1ck_shcontent" ]; then
		stop_fastd1ck
		echo "$fastd1ck_shcontent" >> /koolshare/scripts/fastd1ck_todo.sh
	fi
}

stop_fastd1ck(){
	#killall sh /koolshare/scripts/fastd1ck_todo.sh
	#killall -9 sh /koolshare/scripts/fastd1ck_todo.sh
	jobexist=`cru l|grep fastd1ck`
	# kill crontab job
	if [ -n "$jobexist" ];then
		sed -i '/fastd1ck/d' /var/spool/cron/crontabs/* >/dev/null 2>&1
	fi
	job3exist=`cru l|grep fastd1ck_recover`
	# kill crontab job
	if [ -n "$job3exist" ];then
		sed -i '/fastd1ck_recover/d' /var/spool/cron/crontabs/* >/dev/null 2>&1
	fi
}

fastd1ck_running=0
check_running(){
  fastd1ck_running=`ps |grep $1 |grep -v "grep" |wc -l`
}

case $ACTION in
start)
	if [ "$fastd1ck_enable" == "1" ];then
		logger "[软件中心]: 启动FastD1ck！"
		start_fastd1ck
	else
		logger "[软件中心]: FastD1ck未设置开机启动，Pass！"
	fi
	;;
stop)
	stop_fastd1ck
	;;
recover)
	dbus set fastd1ck_currentI=99
	;;
*)
	if [ "$fastd1ck_enable" == "1" ];then
		start_fastd1ck
	else
		stop_fastd1ck
	fi
	http_response "$1"
	;;
esac
