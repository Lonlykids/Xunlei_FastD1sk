#!/bin/sh

sh /koolshare/scripts/fastd1ck_config.sh stop

rm -rf /koolshare/scripts/uninstall_fastd1ck.sh
rm -rf /koolshare/res/icon-fastd1ck.png
rm -rf /koolshare/scripts/fastd1ck*
rm -rf /koolshare/webs/Module_fastd1ck.asp
rm -rf /koolshare/init.d/*FastD1ck.sh